package Boletin_09;

public enum Genero {
	MASCULINO, FEMENINO, NEUTRO, DESCONOCIDO;
}
