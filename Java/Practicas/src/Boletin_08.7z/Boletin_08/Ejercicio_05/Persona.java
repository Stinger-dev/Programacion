package Boletin_08.Ejercicio_05;

import java.time.LocalDate;

public class Persona {
	private LocalDate fechaNacimiento;
	private String nombre;
	 
	
}
	