package Boletin_08.Ejercicio_07;

public class Main {
	
	public static void main(String[] args) {
	
	}

}
