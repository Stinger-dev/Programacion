package Boletin_10.Euromillones;

public class CombinacionExeption extends Exception {

	public CombinacionExeption() {
		super();
	}

	public CombinacionExeption(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CombinacionExeption(String message, Throwable cause) {
		super(message, cause);
	}

	public CombinacionExeption(String message) {
		super(message);
	}

	public CombinacionExeption(Throwable cause) {
		super(cause);
	}

}
